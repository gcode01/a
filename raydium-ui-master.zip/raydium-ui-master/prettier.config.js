module.exports = {
  tabWidth: 2,
  useTabs: false,
  singleQuote: true,
  semi: false,
  bracketSpacing: true,
  trailingComma: 'none',
  printWidth: 120,
  arrowParens: 'always',
  eslintIntegration: true
}
