import { Notification } from 'ant-design-vue/types/notification'

export interface NuxtNotifyInstance extends Notification {}
