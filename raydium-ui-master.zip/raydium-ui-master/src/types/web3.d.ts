import { Connection } from '@solana/web3.js'

export interface NuxtWeb3Instance extends Connection {}
